for x in range(10):
    print("Hello!")     # 반복할 내용은 빈칸 4개 뒤에 입력합니다(들여쓰기)
