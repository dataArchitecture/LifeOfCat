import turtle as t

d = 100        # 변수 d에 값 100을 저장합니다(수치를 바꾸면 삼각형의 크기가 변합니다).

# 삼각형 그리기
t.forward(d)    # 거북이 d만큼 앞으로 이동
t.left(120)      # 거북이 왼쪽으로 120도 회전
t.forward(d)
t.left(120)
t.forward(d)
t.left(120)
