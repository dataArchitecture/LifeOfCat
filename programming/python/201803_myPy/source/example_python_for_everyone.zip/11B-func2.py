# 인자가 있는 함수
def hello2(name):   # 이름을 인자로 전달받아 Hello와 함께 출력하는 함수
    print("Hello", name)

hello2("Justin")
hello2("John")
hello2("Mike")
